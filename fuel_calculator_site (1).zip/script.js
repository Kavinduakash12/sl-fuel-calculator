
document.getElementById("fuel-form").addEventListener("submit", function (event) {
    event.preventDefault();

    const vehicleType = document.getElementById("vehicle-type").value;
    const fuelEfficiency = parseFloat(document.getElementById("fuel-efficiency").value);
    const tripDistance = parseFloat(document.getElementById("trip-distance").value);
    const fuelPrice = parseFloat(document.getElementById("fuel-price").value);

    if (fuelEfficiency > 0 && tripDistance > 0 && fuelPrice > 0) {
        const fuelUsed = tripDistance / fuelEfficiency;  // Liters of fuel used
        const totalCost = fuelUsed * fuelPrice;  // Total cost for the fuel

        document.getElementById("fuel-usage").textContent = `Fuel used: ${fuelUsed.toFixed(2)} liters`;
        document.getElementById("total-cost").textContent = `Total cost: LKR ${totalCost.toFixed(2)}`;
    } else {
        alert("Please enter valid values.");
    }
});
